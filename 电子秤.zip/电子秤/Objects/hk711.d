.\objects\hk711.o: Hardware\HK711.c
